<!DOCTYPE html>
<html lang="zh-CN">

<head>
<meta charset="utf-8">
<title>Welcome</title>
</head>

<body>
    <div class="content">
        <form class="form sign-in" method="post" action="login.php">
            <label>
                <span>quick login</span>
                <input type="text" name="username"/>
                <input type="password" name="password"/>
                <button type="submit" name="submit">Submit</button>
            </label>
            <label>
        </form>

	<div style="text-align:center;">
</div>
</body>

</html>