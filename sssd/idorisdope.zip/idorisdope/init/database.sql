CREATE DATABASE ctf;
use ctf;
CREATE TABLE normal_users(username varchar(1000), password varchar(1000));
CREATE TABLE super_users(username varchar(1000));
