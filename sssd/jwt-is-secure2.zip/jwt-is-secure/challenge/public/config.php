<?php
define('FLAG', 'Challenge_solved');
define('COOKIE_NAME', 'jwtsession');
define('CHALLENGE_NAME', 'JWT is secure');
