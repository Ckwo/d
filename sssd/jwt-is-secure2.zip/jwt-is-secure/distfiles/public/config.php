<?php
define('FLAG', 'Challenge');
define('COOKIE_NAME', 'jwtsession');
define('CHALLENGE_NAME', 'JWT is secure');
