#!/bin/bash
sqlite3 vote.db < schema.sql