<?php

define("DB_SERVER", "db-myappointments");
define("DB_USER", "db-myappointments");
define("DB_PASS", "db-myappointments");
define("DB_NAME", "db-myappointments");

?>
